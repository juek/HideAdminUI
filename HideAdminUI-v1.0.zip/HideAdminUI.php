<?php
/*
##################################################
PHP class for Typesetter CMS addon 'Hide Admin UI'
Author: J. Krausz
Date: 2018-01-14
Version 1.0
##################################################
*/

defined('is_running') or die('Not an entry point...');

class HideAdminUI{

  public function GetHead() {
    global $page, $addonRelativeCode, $langmessage;
    if( !\gp\tool::LoggedIn() || !$page->title ){
      return;
    }
    $page->css_admin[] =  $addonRelativeCode . '/HideAdminUI.css';
    $page->head_js[] =    $addonRelativeCode . '/HideAdminUI.js';
    $page->jQueryCode .= "\n" 
      . '$("#admincontent_panel > ul").first()'
      . '.prepend("<li class=\"hide-admin-ui\" title=\"'
      . $langmessage['Tools'] 
      . ' [Ctrl]+[H]\"><a><i class=\"fa fa-window-maximize\"></i></a></li>")'
      . '.on("click", HideAdminUI.hide);'
      . "\n\n"
      . '$("<div class=\"show-admin-ui\" title=\"'
      . $langmessage['Tools'] 
      . '[Ctrl]+[H]\">'
      . '<i class=\"fa fa-window-restore\"></i>'
      . '</div>").on("click", HideAdminUI.show)'
      . '.appendTo("body");'
      . "\n";
  }

}

